#!/bin/sh
set -eu
mkdir -p /metadata/preparation /worktrees
tar -xzf /opt/apache-maven-3.9.16-bin.tar.gz -C /opt
tar -xzf /opt/apache-maven-3.9.11-bin.tar.gz -C /opt
mkdir -p /metadata/preparation/commons-dbutils
git init -q /worktrees/commons-dbutils
git -C /worktrees/commons-dbutils remote add origin https://github.com/apache/commons-dbutils.git
timeout 180 git -C /worktrees/commons-dbutils fetch --depth 1 origin e1e2d9edfab8f237aab9e733c6d61e23b35d2079 >/metadata/preparation/commons-dbutils/fetch.log 2>&1
git -C /worktrees/commons-dbutils checkout --detach FETCH_HEAD >>/metadata/preparation/commons-dbutils/fetch.log 2>&1
git -C /worktrees/commons-dbutils rev-parse HEAD >/metadata/preparation/commons-dbutils/HEAD.txt
/opt/apache-maven-3.9.16/bin/mvn --version >/metadata/preparation/commons-dbutils/runtime.txt 2>&1
cd /worktrees/commons-dbutils
timeout 180 /opt/apache-maven-3.9.16/bin/mvn -B -f pom.xml -V --batch-mode org.apache.maven.plugins:maven-help-plugin:3.5.2:effective-pom -Dverbose -Doutput=/metadata/preparation/commons-dbutils/effective-pom.xml >/metadata/preparation/commons-dbutils/effective-pom.log 2>&1
timeout 180 /opt/apache-maven-3.9.16/bin/mvn -B -f pom.xml -V --batch-mode org.apache.maven.plugins:maven-help-plugin:3.5.2:effective-settings -Dverbose -Doutput=/metadata/preparation/commons-dbutils/effective-settings.xml >/metadata/preparation/commons-dbutils/effective-settings.log 2>&1
git diff --name-only HEAD -- >/metadata/preparation/commons-dbutils/tracked-diff.txt
git ls-files --others --exclude-standard >/metadata/preparation/commons-dbutils/untracked.txt
find /root/.m2/repository -name "*.pom" -o -name "*.jar" | sort >/metadata/preparation/commons-dbutils/metadata-repository-files.txt
mkdir -p /metadata/preparation/commons-net
git init -q /worktrees/commons-net
git -C /worktrees/commons-net remote add origin https://github.com/apache/commons-net.git
timeout 180 git -C /worktrees/commons-net fetch --depth 1 origin ac1ca59667b945ec95b54e503c7b4415fd5e0276 >/metadata/preparation/commons-net/fetch.log 2>&1
git -C /worktrees/commons-net checkout --detach FETCH_HEAD >>/metadata/preparation/commons-net/fetch.log 2>&1
git -C /worktrees/commons-net rev-parse HEAD >/metadata/preparation/commons-net/HEAD.txt
/opt/apache-maven-3.9.11/bin/mvn --version >/metadata/preparation/commons-net/runtime.txt 2>&1
cd /worktrees/commons-net
timeout 180 /opt/apache-maven-3.9.11/bin/mvn -B -f pom.xml -V --no-transfer-progress --batch-mode org.apache.maven.plugins:maven-help-plugin:3.5.2:effective-pom -Dverbose -Doutput=/metadata/preparation/commons-net/effective-pom.xml >/metadata/preparation/commons-net/effective-pom.log 2>&1
timeout 180 /opt/apache-maven-3.9.11/bin/mvn -B -f pom.xml -V --no-transfer-progress --batch-mode org.apache.maven.plugins:maven-help-plugin:3.5.2:effective-settings -Dverbose -Doutput=/metadata/preparation/commons-net/effective-settings.xml >/metadata/preparation/commons-net/effective-settings.log 2>&1
git diff --name-only HEAD -- >/metadata/preparation/commons-net/tracked-diff.txt
git ls-files --others --exclude-standard >/metadata/preparation/commons-net/untracked.txt
find /root/.m2/repository -name "*.pom" -o -name "*.jar" | sort >/metadata/preparation/commons-net/metadata-repository-files.txt
mkdir -p /metadata/preparation/tomcat-jakartaee-migration
git init -q /worktrees/tomcat-jakartaee-migration
git -C /worktrees/tomcat-jakartaee-migration remote add origin https://github.com/apache/tomcat-jakartaee-migration.git
timeout 180 git -C /worktrees/tomcat-jakartaee-migration fetch --depth 1 origin c06f68f13f28448b1bea8a79bcc6ba4966490dcf >/metadata/preparation/tomcat-jakartaee-migration/fetch.log 2>&1
git -C /worktrees/tomcat-jakartaee-migration checkout --detach FETCH_HEAD >>/metadata/preparation/tomcat-jakartaee-migration/fetch.log 2>&1
git -C /worktrees/tomcat-jakartaee-migration rev-parse HEAD >/metadata/preparation/tomcat-jakartaee-migration/HEAD.txt
/opt/apache-maven-3.9.16/bin/mvn --version >/metadata/preparation/tomcat-jakartaee-migration/runtime.txt 2>&1
cd /worktrees/tomcat-jakartaee-migration
timeout 180 /opt/apache-maven-3.9.16/bin/mvn -V --file pom.xml --no-transfer-progress org.apache.maven.plugins:maven-help-plugin:3.5.2:effective-pom -Dverbose -Doutput=/metadata/preparation/tomcat-jakartaee-migration/effective-pom.xml >/metadata/preparation/tomcat-jakartaee-migration/effective-pom.log 2>&1
timeout 180 /opt/apache-maven-3.9.16/bin/mvn -V --file pom.xml --no-transfer-progress org.apache.maven.plugins:maven-help-plugin:3.5.2:effective-settings -Dverbose -Doutput=/metadata/preparation/tomcat-jakartaee-migration/effective-settings.xml >/metadata/preparation/tomcat-jakartaee-migration/effective-settings.log 2>&1
git diff --name-only HEAD -- >/metadata/preparation/tomcat-jakartaee-migration/tracked-diff.txt
git ls-files --others --exclude-standard >/metadata/preparation/tomcat-jakartaee-migration/untracked.txt
find /root/.m2/repository -name "*.pom" -o -name "*.jar" | sort >/metadata/preparation/tomcat-jakartaee-migration/metadata-repository-files.txt
mkdir -p /metadata/preparation/commons-csv
git init -q /worktrees/commons-csv
git -C /worktrees/commons-csv remote add origin https://github.com/apache/commons-csv.git
timeout 180 git -C /worktrees/commons-csv fetch --depth 1 origin bb0f0fbb0f84de5cf5a0c73a9fa7051fb5135650 >/metadata/preparation/commons-csv/fetch.log 2>&1
git -C /worktrees/commons-csv checkout --detach FETCH_HEAD >>/metadata/preparation/commons-csv/fetch.log 2>&1
git -C /worktrees/commons-csv rev-parse HEAD >/metadata/preparation/commons-csv/HEAD.txt
/opt/apache-maven-3.9.16/bin/mvn --version >/metadata/preparation/commons-csv/runtime.txt 2>&1
cd /worktrees/commons-csv
timeout 180 /opt/apache-maven-3.9.16/bin/mvn -Ddoclint=all --show-version --batch-mode --no-transfer-progress org.apache.maven.plugins:maven-help-plugin:3.5.2:effective-pom -Dverbose -Doutput=/metadata/preparation/commons-csv/effective-pom.xml >/metadata/preparation/commons-csv/effective-pom.log 2>&1
timeout 180 /opt/apache-maven-3.9.16/bin/mvn -Ddoclint=all --show-version --batch-mode --no-transfer-progress org.apache.maven.plugins:maven-help-plugin:3.5.2:effective-settings -Dverbose -Doutput=/metadata/preparation/commons-csv/effective-settings.xml >/metadata/preparation/commons-csv/effective-settings.log 2>&1
git diff --name-only HEAD -- >/metadata/preparation/commons-csv/tracked-diff.txt
git ls-files --others --exclude-standard >/metadata/preparation/commons-csv/untracked.txt
find /root/.m2/repository -name "*.pom" -o -name "*.jar" | sort >/metadata/preparation/commons-csv/metadata-repository-files.txt
mkdir -p /metadata/preparation/commons-dbcp
git init -q /worktrees/commons-dbcp
git -C /worktrees/commons-dbcp remote add origin https://github.com/apache/commons-dbcp.git
timeout 180 git -C /worktrees/commons-dbcp fetch --depth 1 origin d16b6a36bba2eb70270a709642df8e7792cf2a6e >/metadata/preparation/commons-dbcp/fetch.log 2>&1
git -C /worktrees/commons-dbcp checkout --detach FETCH_HEAD >>/metadata/preparation/commons-dbcp/fetch.log 2>&1
git -C /worktrees/commons-dbcp rev-parse HEAD >/metadata/preparation/commons-dbcp/HEAD.txt
/opt/apache-maven-3.9.16/bin/mvn --version >/metadata/preparation/commons-dbcp/runtime.txt 2>&1
cd /worktrees/commons-dbcp
timeout 180 /opt/apache-maven-3.9.16/bin/mvn --errors --show-version --batch-mode --no-transfer-progress org.apache.maven.plugins:maven-help-plugin:3.5.2:effective-pom -Dverbose -Doutput=/metadata/preparation/commons-dbcp/effective-pom.xml >/metadata/preparation/commons-dbcp/effective-pom.log 2>&1
timeout 180 /opt/apache-maven-3.9.16/bin/mvn --errors --show-version --batch-mode --no-transfer-progress org.apache.maven.plugins:maven-help-plugin:3.5.2:effective-settings -Dverbose -Doutput=/metadata/preparation/commons-dbcp/effective-settings.xml >/metadata/preparation/commons-dbcp/effective-settings.log 2>&1
git diff --name-only HEAD -- >/metadata/preparation/commons-dbcp/tracked-diff.txt
git ls-files --others --exclude-standard >/metadata/preparation/commons-dbcp/untracked.txt
find /root/.m2/repository -name "*.pom" -o -name "*.jar" | sort >/metadata/preparation/commons-dbcp/metadata-repository-files.txt
