#!/usr/bin/env python3
"""Metadata-only preparation of frozen original tasks. Never run lifecycle goals."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

BASE = Path('/metadata/preparation')
WORK = Path('/worktrees')
VALUES = {'-f', '--file', '-pl', '--projects', '-P', '--activate-profiles', '-s', '--settings', '-gs', '--global-settings', '-t', '--toolchains', '-gt', '--global-toolchains', '-T', '--threads', '-rf', '--resume-from', '-D', '--define', '-l', '--log-file'}
HELP = 'org.apache.maven.plugins:maven-help-plugin:3.5.2:'
CURRENT_SCRIPT_REF = None


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def ref(path):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(BASE)), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def metadata_options(argv):
    keep, pending = [], False
    for arg in argv[1:]:
        if pending:
            keep.append(arg)
            pending = False
        elif arg in VALUES:
            keep.append(arg)
            pending = True
        elif arg.startswith('-'):
            keep.append(arg)
    if pending:
        raise ValueError('Unpaired metadata configuration option')
    return keep


def run(argv, cwd, log, env=None, timeout=240):
    started = time.time()
    code, state = None, 'unavailable'
    with log.open('wb') as output:
        try:
            done = subprocess.run(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT, timeout=timeout, check=False)
            code, state = done.returncode, 'completed'
        except (OSError, subprocess.TimeoutExpired) as exc:
            output.write((type(exc).__name__ + ': ' + str(exc)).encode())
            state = 'timeout' if isinstance(exc, subprocess.TimeoutExpired) else 'unavailable'
    return {'argv': argv, 'cwd': str(cwd), 'exit_code': code, 'status': state, 'elapsed_seconds': round(time.time() - started, 3), 'log': ref(log)}


def capture_inputs(checkout, destination, commit):
    """Public tracked launcher/config bytes; no cache or inherited environment."""
    output = destination / 'launcher-inputs'
    output.mkdir(exist_ok=True)
    proc = subprocess.run(['git', '-C', str(checkout), 'ls-files', '-z', '--', 'mvnw', 'mvnw.cmd', '.mvn'], capture_output=True, check=False)
    (output / 'tracked-files.raw').write_bytes(proc.stdout)
    (output / 'tracked-files.stderr').write_bytes(proc.stderr)
    if proc.returncode != 0:
        return {'status': 'unavailable', 'exit_code': proc.returncode}
    records = []
    names = [part.decode() for part in proc.stdout.split(b'\0') if part]
    for name in names:
        source = checkout / name
        if source.is_symlink():
            records.append({'path': name, 'kind': 'symlink', 'target': os.readlink(source)})
            continue
        if not source.is_file():
            records.append({'path': name, 'kind': 'missing'})
            continue
        target = output / name
        target.parent.mkdir(parents=True, exist_ok=True)
        raw = source.read_bytes()
        pinned = subprocess.run(['git', '-C', str(checkout), 'show', commit + ':' + name], capture_output=True, check=False)
        target.write_bytes(raw)
        records.append({'source_path': name, 'kind': 'file', 'pinned_bytes_equal': pinned.returncode == 0 and pinned.stdout == raw, **ref(target)})
    required = ['mvnw', 'mvnw.cmd', '.mvn/maven.config', '.mvn/jvm.config', '.mvn/extensions.xml', '.mvn/wrapper/maven-wrapper.properties', '.mvn/wrapper/maven-wrapper.jar']
    inventory = {'commit': commit, 'tracked_inventory': ref(output / 'tracked-files.raw'), 'tracked_inventory_stderr': ref(output / 'tracked-files.stderr'), 'files': records, 'absent_tracked_paths': [p for p in required if p not in names], 'scope': 'git tracked launcher/config paths at pinned commit; not a wrapper approval'}
    save(output / 'index.json', inventory)
    return {'status': 'captured', 'index': ref(output / 'index.json')}


def prepare(project):
    name = project['id']
    destination = BASE / name
    destination.mkdir(exist_ok=True)
    request = {'project_id': name, 'repo': project['repo'], 'commit': project['commit'], 'original_task': project['steps'][0], 'original_steps': project['steps'], 'cache_policy': 'isolated_metadata_only_not_shared_with_agent'}
    save(BASE / ('request-' + name + '.json'), request)
    state = {'project': name, 'repo': project['repo'], 'commit': project['commit'], 'status': 'preparing', 'metadata_only': True, 'preparation_script': CURRENT_SCRIPT_REF, 'commands': [], 'steps': [], 'disk_free_before': shutil.disk_usage(BASE).free}
    state_path = destination / 'metadata-status.json'
    save(state_path, state)
    checkout = WORK / name
    checkout.mkdir(parents=True, exist_ok=True)
    if not (checkout / '.git').exists():
        for argv in (['git', 'init', '-q'], ['git', 'remote', 'add', 'origin', 'https://github.com/' + project['repo'] + '.git']):
            subprocess.run(argv, cwd=checkout, check=True, capture_output=True)
    current = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=checkout, capture_output=True, check=False).stdout.decode().strip()
    if current != project['commit']:
        dirty = subprocess.run(['git', 'status', '--porcelain'], cwd=checkout, capture_output=True, check=False).stdout
        if dirty:
            state['status'] = 'blocked_existing_checkout_changes'
            save(state_path, state)
            return state
        fetch = run(['git', 'fetch', '--depth', '1', 'origin', project['commit']], checkout, destination / 'fetch.log')
        state['commands'].append(fetch)
        if fetch['exit_code'] != 0:
            state['status'] = 'source_fetch_unavailable'
            save(state_path, state)
            return state
        checked = run(['git', 'checkout', '--detach', 'FETCH_HEAD'], checkout, destination / 'checkout.log')
        state['commands'].append(checked)
        if checked['exit_code'] != 0:
            state['status'] = 'source_checkout_unavailable'
            save(state_path, state)
            return state
    head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=checkout, capture_output=True, check=True).stdout
    (destination / 'HEAD.txt').write_bytes(head)
    if head.decode().strip() != project['commit']:
        raise ValueError('Pinned HEAD mismatch')
    state['launcher_inputs'] = capture_inputs(checkout, destination, project['commit'])
    for index, step in enumerate(project['steps']):
        target = destination if len(project['steps']) == 1 else destination / step['id']
        target.mkdir(exist_ok=True)
        java = step.get('java_major')
        java_home = Path('/usr/lib/jvm/java-' + str(java) + '-openjdk-amd64')
        result = {'id': step['id'], 'frozen_argv': step['argv'], 'java_major': java, 'maven_version_constraint': step.get('maven_version'), 'status': 'preparing'}
        state['steps'].append(result)
        if not java_home.is_dir():
            result['status'] = 'runtime_unavailable'
            save(state_path, state)
            continue
        env = dict(os.environ)
        env.update(step.get('environment', {}))
        env.update(JAVA_HOME=str(java_home), MAVEN_OPTS='-Xmx1024m', MAVEN_SKIP_RC='true')
        env['PATH'] = str(java_home / 'bin') + ':' + env.get('PATH', '')
        if step['argv'][0] == './mvnw':
            launcher = str(checkout / 'mvnw')
        elif step['argv'][0] == 'mvn':
            launcher = '/opt/apache-maven-' + (step.get('maven_version') or '3.9.16') + '/bin/mvn'
        else:
            result['status'] = 'launcher_unavailable'
            continue
        result['metadata_environment'] = {k: env[k] for k in ('JAVA_HOME', 'MAVEN_OPTS', 'MAVEN_SKIP_RC')}
        result['launcher'] = launcher
        probe = run([launcher, '--version'], checkout, target / 'runtime.txt', env)
        result['runtime_probe'] = probe
        runtime = (target / 'runtime.txt').read_text(errors='replace')
        observed = re.search(r'Apache Maven\s+(\d+\.\d+\.\d+)', runtime)
        result['observed_maven_version'] = observed[1] if observed else None
        observed_java = re.search(r'Java version:\s*(?:1\.)?(\d+)', runtime)
        result['observed_java_major'] = int(observed_java[1]) if observed_java else None
        if probe['exit_code'] != 0 or observed is None or result['observed_java_major'] != java or step.get('maven_version') and observed[1] != step['maven_version']:
            result['status'] = 'runtime_probe_failed_or_mismatch'
            save(state_path, state)
            continue
        options = metadata_options(step['argv'])
        if '-q' not in options and '--quiet' not in options:
            assert not any(token in options for token in ('clean', 'test', 'verify', 'install', 'package'))
        result['metadata_options'] = options
        result['commands'] = []
        for goal in ('effective-pom', 'effective-settings'):
            output = target / (goal + '.xml')
            argv = [launcher, *options, HELP + goal, '-Dverbose', '-Doutput=' + str(output)]
            evidence = run(argv, checkout / step.get('cwd', '.'), target / (goal + '.log'), env)
            result['commands'].append(evidence)
            save(state_path, state)
            if evidence['exit_code'] != 0 or not output.is_file():
                result['status'] = 'metadata_capture_failed'
                break
        else:
            result['status'] = 'captured_review_required'
            result['outputs'] = {goal: ref(target / (goal + '.xml')) for goal in ('effective-pom', 'effective-settings')}
        save(state_path, state)
    for argv, name in ((['git', 'diff', '--name-only', 'HEAD', '--'], 'tracked-diff.txt'), (['git', 'ls-files', '--others', '--exclude-standard'], 'untracked.txt')):
        done = subprocess.run(argv, cwd=checkout, capture_output=True, check=True)
        (destination / name).write_bytes(done.stdout)
    state['status'] = 'captured_review_required' if state['steps'] and all(s['status'] == 'captured_review_required' for s in state['steps']) else 'incomplete_metadata'
    state['disk_free_after'] = shutil.disk_usage(BASE).free
    save(state_path, state)
    return state


def main():
    global CURRENT_SCRIPT_REF
    raw_script = Path(__file__).read_bytes()
    script_path = BASE / 'runner-sources' / (hashlib.sha256(raw_script).hexdigest() + '.py')
    script_path.parent.mkdir(exist_ok=True)
    if not script_path.exists():
        script_path.write_bytes(raw_script)
    CURRENT_SCRIPT_REF = ref(script_path)
    parser = argparse.ArgumentParser()
    parser.add_argument('projects', nargs='+')
    args = parser.parse_args()
    config = json.loads((BASE / 'remaining-inputs.json').read_text())
    projects = {p['id']: p for p in config['projects']}
    states = []
    for name in args.projects:
        project = projects[name]
        if any(s['runner'] != 'maven' for s in project['steps']):
            raise ValueError('Only Maven metadata tasks are admitted')
        print(json.dumps({'project': name, 'event': 'metadata_start'}), flush=True)
        try:
            state = prepare(project)
        except Exception as exc:
            state = {'project': name, 'status': 'preparation_error', 'error': type(exc).__name__ + ': ' + str(exc)}
        states.append(state)
        save(BASE / 'last-preparation-batch.json', states)
        print(json.dumps({'project': name, 'event': 'metadata_finished', 'status': state['status']}), flush=True)


if __name__ == '__main__':
    main()
