import hashlib, json, re, shutil
from pathlib import Path
from html.parser import HTMLParser
from scripts.build_benchmark_requirements import xml_root, text_at, pom_execution_bindings, ci_binding_inventory, task_digest

B = Path('output/sag-benchmark20-requirements-20260922').resolve()
OLD = Path('output/sag-benchmark20-20260917').resolve()
class Console(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.active = False
        self.count = 0
        self.parts = []
    def handle_starttag(self, tag, attrs):
        if tag == 'pre' and 'console-output' in dict(attrs).get('class', '').split():
            if self.active:
                raise ValueError('nested console pre')
            self.count += 1
            self.active = True
        elif self.active and tag in {'script', 'style', 'pre'}:
            raise ValueError('unexpected embedded executable/text container')
    def handle_endtag(self, tag):
        if tag == 'pre':
            self.active = False
    def handle_data(self, data):
        if self.active:
            self.parts.append(data)
    def value(self):
        if self.active or self.count != 1:
            raise ValueError('requires exactly one closed console-output pre')
        return ''.join(self.parts)

def ref(path, basis, url=None):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(B)), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw), 'basis': basis, 'source_archive': str(path), 'official_url': url}

def review_project(name, preparation_script):
    task = json.loads((B/'tasks'/f'{name}.json').read_text())
    prep = B/'preparation'/name
    support = B/'review-support'/name
    support.mkdir(parents=True, exist_ok=True)
    archive = OLD/'ci'/name
    index = json.loads((archive/'index.json').read_text())
    node_ref = next(x for x in index['evidence'] if x['path'].endswith('node-console.html'))
    node = OLD/node_ref['path']
    assert hashlib.sha256(node.read_bytes()).hexdigest() == node_ref['sha256']
    selected = support/node.name
    shutil.copyfile(node, selected)
    parser = Console(); parser.feed(selected.read_text()); parser.close(); text = parser.value()
    log = support/'selected-node.log';log.write_bytes(text.encode())
    index_copy = support/'frozen-ci-index.json';shutil.copyfile(archive/'index.json',index_copy)
    stage = next(archive.glob('*stage.json'));stage_copy=support/stage.name;shutil.copyfile(stage,stage_copy)
    script = support/'review-source.py';shutil.copyfile(Path(__file__),script)
    root = xml_root((prep/'effective-pom.xml').read_bytes())
    module=text_at(root,'artifactId');version=text_at(root,'version');group=text_at(root,'groupId')
    assert (prep/'HEAD.txt').read_text().strip() == task['sha']
    assert not (prep/'tracked-diff.txt').read_bytes().strip()
    assert not (prep/'untracked.txt').read_bytes().strip()
    coordinates={'group_id':group,'artifact_id':module,'version':version}
    final_name=text_at(root,'build/finalName');assert final_name==module+'-'+version
    top,nested=ci_binding_inventory(text)
    observed={(r['goal'],r['version'],r['execution']) for r in top}
    requirements=[]
    enforcers={'enforce-maven-version':'maven_policy','enforce-java-version':'java_policy','enforce-sling-java-version':'sling_java_policy','enforce-explicit-scope':'dependency_scope_policy','enforce-scope-of-annotation-deps':'annotation_dependency_scope_policy','ban-plugins-and-dependencies':'plugin_and_dependency_policy'}
    selected_map={
      ('spotless:check','default'):('quality_check','format','native_goal','Java and POM formatting check, including native per-file validation.'),
      ('compiler:compile','default-compile'):('compile','production_sources','native_goal','Production-source compilation in the selected CI cell.'),
      ('compiler:testCompile','default-testCompile'):('compile','test_sources','native_goal','Test-source compilation in the selected CI cell.'),
      ('surefire:test','default-test'):('test','unit','junit','Complete native Surefire result plus fresh XML report collection; skipped cases remain separately counted.'),
      ('jar:jar','default-jar'):('package','main_jar','artifact','Main JAR uses the Bnd-produced OSGi manifest; Maven packaging is jar, not bundle.'),
      ('source:jar-no-fork','attach-sources'):('package','source_jar','artifact','Source JAR is explicitly attached and installed in the selected CI cell.'),
      ('tools:verify-legal-files','verify-legal-files'):('quality_check','artifact_legal_files','native_goal','Checks required legal files inside both main and sources JARs, distinct from RAT worktree license scan.'),
      ('apache-rat:check','rat-check'):('quality_check','license','native_goal','RAT verifies the source/worktree license inventory; unfamiliar agent-created files remain attributable risks.'),
      ('jacoco:report','report'):('quality_check','unit_coverage_report','native_goal','Creates the unit-coverage report; no numeric coverage threshold is declared.'),
      ('jacoco:report','report-merged'):('quality_check','merged_coverage_report','native_goal','Creates the merged-coverage report using the available unit data; it does not imply integration tests ran.'),
      ('bnd-baseline:baseline','bnd-baseline'):('quality_check','osgi_api_compatibility','native_goal','Compares the built OSGi bundle with the previous released version downloaded from a configured repository; this is a network-sensitive compatibility check.'),
      ('install:install','default-install'):('install','local_repository_artifacts','install','Installs main JAR, source JAR, and POM in the observed effective local Maven repository.'),
      ('javadoc:javadoc','default-cli'):('documentation','javadoc','native_goal','Explicit Javadoc HTML generation follows install in the frozen variant; no Javadoc JAR is attached.')
    }
    support_reasons={
      'clean:clean':'Removes prior output before the build; exact full command completion retains this obligation.',
      'jacoco:prepare-agent':'Sets the unit-test instrumentation arguments; subsequent report generation is a separate requirement.',
      'remote-resources:process':'Copies and appends the Apache/Sling LICENSE/NOTICE resources later checked in packaged JARs.',
      'resources:resources':'Copies production resources consumed by compilation/packaging.',
      'bnd:bnd-process':'Prepares OSGi metadata for the main JAR; its execution remains required by complete command and subsequent bundle baseline validation.',
      'resources:testResources':'Copies available test resources; absence of a source test-resource directory does not disable the entire goal.',
      'dependency:copy-dependencies':'Copies test bundle dependencies used by unit tests; these are test inputs, not project deliverable artifacts.',
      'jacoco:prepare-agent-integration':'Prepares potential integration-test instrumentation. This project has no Failsafe test binding in the frozen plan and no integration-data file in CI.',
      'jacoco:merge':'Merges the available unit coverage data; the separate merged-report requirement verifies downstream generation.'
    }
    task_position=0
    for row in top:
        key=(row['goal'],row['execution'])
        if row['goal']=='deploy:deploy':
            row.update(disposition='excluded_declared_variant', reason='The frozen task explicitly replaces publication-only deploy with install and removes altDeploymentRepository. Keep the observed deploy occurrence in original CI provenance; it is not an obligation of this declared task variant.',task_position=None)
            continue
        row['task_position']=task_position;task_position+=1
        if row['goal']=='jacoco:report-integration':
            assert '[INFO] Skipping JaCoCo execution due to missing execution data file.' in text.splitlines()[row['line']]
            row.update(disposition='ci_disabled',reason='Official report-integration prints Skipping JaCoCo execution due to missing execution data file; do not infer integration tests or a completed integration-coverage report.')
            continue
        if row['goal']=='enforcer:enforce':
            category=('quality_check',enforcers[row['execution']],'native_goal','Explicit '+row['execution']+' policy check; each execution is independently retained.')
        else: category=selected_map.get(key)
        if category:
            kind,subtype,rule,reason=category; rid='ci-step-1-'+subtype
            row.update(disposition='requirement',requirement_id=rid,reason=reason)
            expectations={}
            if kind=='package':
                source=subtype=='source_jar';classifier='sources' if source else None
                expectations={'artifacts':[{'path':'target/'+final_name+('-sources' if source else '')+'.jar','role':'sources' if source else 'main','module':module,'evidence_tier':'declared','extension':'jar','classifier':classifier,'coordinates':coordinates}]}
            elif kind=='install':
                artifacts=[]
                for extension,classifier,role in [('pom',None,'installed_pom'),('jar',None,'installed_main'),('jar','sources','installed_attached')]:
                    filename=final_name+('-'+classifier if classifier else '')+'.'+extension
                    artifacts.append({'module':module,'evidence_tier':'declared','extension':extension,'classifier':classifier,'coordinates':coordinates,'role':role,'repository_relative_path':group.replace('.','/')+'/'+module+'/'+version+'/'+filename})
                expectations={'artifacts':artifacts}
            requirements.append({'id':rid,'kind':kind,'subtype':subtype,'validation':{'rule':rule},'depends_on':[requirements[-1]['id']] if requirements else [],'dependencies_complete':True,'expectations':expectations})
        else:
            row.update(disposition='support',reason=support_reasons[row['goal']])
    for row in nested:
        row.update(disposition='fork_support',reason='Nested execution inside the explicit Javadoc generate-sources fork; retained in provenance and command completion, never a substitute for the corresponding top-level requirement.')
    pom_rows=pom_execution_bindings(root)
    for row in pom_rows:
        if (row['goal'],row['version'],row['execution']) in observed:
            row.update(disposition='observed',reason='Exact goal/version/execution observed in the selected independent official Linux JDK17 node log.')
            if row['goal']=='deploy:deploy':
                row.update(task_disposition='excluded_declared_variant',task_reason='Official deploy is beyond the frozen install endpoint; its removal is explicitly declared in the original frozen CI index.')
        elif row['phase'] in ('site','site-deploy'):
            row.update(disposition='outside_task_lifecycle',reason='Separate site lifecycle is not selected; explicit javadoc:javadoc does not run site or site-deploy.')
        else:raise ValueError(('unreviewed POM execution',name,row))
    paths={k:prep/f for k,f in {'effective_pom':'effective-pom.xml','effective_settings':'effective-settings.xml','pom_log':'effective-pom.log','settings_log':'effective-settings.log','runtime':'runtime.txt','head':'HEAD.txt','tracked_diff':'tracked-diff.txt','untracked':'untracked.txt'}.items()}
    paths.update(preparation_request=B/'preparation'/f'request-{name}.json',preparation_script=preparation_script,official_ci=log)
    result={'source_paths_relative_to':'requirements_bundle_root','schema_version':1,'review_protocol':'single-module-maven-v1','project_id':name,'commit':task['sha'],'task_sha256':task_digest(task),'reviewed_by':'Codex source-bound metadata review, 2026-09-22','review_status':'source_bound_pending_importer_integration','importable':False,'review_notes':[
       'Definition review only; no build, test or agent run performed by this review. Completeness is conditional on verified archived node lineage and the preexisting declared deployment variant; publication is not evaluated.',
       'The independent official node log is extracted without selective line filtering from one Jenkins console-output pre. The original HTML, selected-node stage and original CI index remain byte bound.',
       'Official deploy -> frozen local install is an already declared task variant. Retain the original deploy occurrence with an explicit exclusion; all other ordered top-level and nested occurrences remain visible.',
       'Maven packaging defaults to jar; Bnd prepares OSGi metadata and performs released-version baseline comparison. Required deliverables are a main JAR, a sources-classifier JAR, plus installed POM; no bundle-extension or Javadoc-classifier artifact is invented.',
       'JaCoCo integration report is natively skipped because integration execution data is absent. Unit and merged reports are required, but no integration-test success or numeric coverage threshold is inferred.',
       'Dependencies encode the projected single-module serial fail-fast task order, not parallel graph scheduling. Native position fields retain original CI values; task_position is explicit projected variant order and is not yet importer-validated.',
       'Task JDK17 and Maven3.9.16 pins remain unchanged. Metadata cache is isolated and must not be supplied to agent runs.'
    ],'unresolved_importer_capabilities':[
       {'id':'selected_node_html_lineage','detail':'The current importer only anchors the mixed full-job console hash present in draft goal sources; it cannot verify a selected-node HTML extraction against frozen CI index/stage lineage.'},
       {'id':'declared_deploy_to_install_variant','detail':'The current single-module importer has no explicit excluded_declared_variant disposition or CI-position to frozen-task-position projection. Do not relabel deploy as support or silently remove it.'}
    ],'module':{'id':module,'path':'.'},'metadata_workspace':'/worktrees/'+name,'selected_goals':['clean','install','javadoc:javadoc'],'sources':{k:ref(p,'reviewed_'+k,node_ref['official_url'] if k=='official_ci' else None) for k,p in paths.items()},'additional_sources':{'original_node_html':ref(selected,'official_selected_node_html',node_ref['official_url']),'frozen_ci_index':ref(index_copy,'frozen_ci_index'),'selected_stage':ref(stage_copy,'official_selected_stage',next(e['official_url'] for e in index['evidence'] if e['path'].endswith('stage.json'))),'review_extractor':ref(script,'review_only_html_transport_extractor'),'metadata_status':ref(prep/'metadata-status.json','metadata_preparation_status')},'ci_log_transform':{'rule':'stdlib HTMLParser, convert_charrefs=True; concatenate all handle_data payloads only inside the unique closed pre.console-output; reject nested pre/script/style; no native log line filtering','raw_source_key':'original_node_html','result_source_key':'official_ci','output_encoding':'utf-8'},'declared_variant':{'classification':'ci_declared_variant','original_command':index['original_command'],'task_argv':task['steps'][0]['argv'],'preexisting_frozen_note':next(note for note in index['notes'] if 'deploy is replaced' in note),'removed_goal':'deploy:deploy','removed_option':'-DaltDeploymentRepository','publication_comparable':False},'pom_bindings':pom_rows,'ci_bindings':top,'nested_ci_bindings':nested,'requirements':requirements,'artifact_scope_exceptions':[{'classification':'jar_with_osgi_manifest','reason':'Neither POM declares bundle packaging. Bnd processing prepares OSGi metadata in the main jar; classifier and file suffix are preserved from native jar/install output.'},{'classification':'javadoc_html_not_attached_jar','reason':'The selected explicit goal is javadoc:javadoc, and all three official local-repository writes omit a javadoc classifier.'}]}
    result['ci_source'] = {'kind':'jenkins-selected-node-v1','raw_html':result['additional_sources']['original_node_html'],'index':result['additional_sources']['frozen_ci_index'],'stage':result['additional_sources']['selected_stage'],'selected_node_url':node_ref['official_url']}
    # Reconcile all install paths against raw selected-node writes before saving a candidate plan.
    installs=next(r for r in requirements if r['kind']=='install')['expectations']['artifacts']
    writes=re.findall(r'^\[INFO\] Installing (.+) to (.+)\s*$',text,re.M)
    assert len(writes)==len(installs)==3
    for artifact in installs:assert sum(dest.endswith('/'+artifact['repository_relative_path']) for _,dest in writes)==1
    assert len(requirements)==19
    p=B/f'review-{name}.json';p.write_text(json.dumps(result,indent=2)+'\n')
    return {'project':name,'review':str(p),'candidate_requirements':len(requirements),'top_ci':len(top),'nested_ci':len(nested),'pom_bindings':len(pom_rows),'importable':False}

if __name__=='__main__':
    import sys
    for name,script in zip(sys.argv[1::2],sys.argv[2::2]):print(json.dumps(review_project(name,Path(script).resolve())))
